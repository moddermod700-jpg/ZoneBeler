# BelerZone — Site complet de vente de beats

## Structure du projet
```
belerzone/
├── backend/          → API REST Node.js/Express (à déployer sur Railway)
│   ├── server.js
│   ├── db.js
│   ├── schema.sql    → à exécuter dans Supabase
│   ├── routes/
│   └── middleware/
└── frontend/         → Site statique (à déployer sur Netlify)
    ├── index.html
    ├── admin/         → interface admin
    ├── css/
    └── js/
```

## 1. Base de données (Supabase)
1. Créez un projet sur https://supabase.com
2. Allez dans **SQL Editor** et exécutez le contenu de `backend/schema.sql`
3. Allez dans **Project Settings > Database > Connection string > URI** et copiez l'URL
   (remplacez `[YOUR-PASSWORD]` par le mot de passe de votre base)

## 2. Back-end (Railway)
1. Créez un compte sur https://railway.app
2. "New Project" → "Deploy from GitHub repo" → sélectionnez le dossier `backend/`
3. Dans les **Variables** du projet Railway, ajoutez :
   - `DATABASE_URL` = l'URL Supabase copiée à l'étape 1
   - `JWT_SECRET` = une chaîne aléatoire longue (ex: générée avec `openssl rand -hex 32`)
   - `FRONTEND_URL` = l'URL de votre site Netlify (à mettre à jour après l'étape 3)
4. Railway installera automatiquement les dépendances (`npm install`) et lancera `npm start`
5. Notez l'URL publique générée par Railway (ex: `https://belerzone-backend.up.railway.app`)

## 3. Front-end (Netlify)
1. Modifiez `frontend/js/config.js` et remplacez `API_URL` par l'URL Railway obtenue à l'étape 2
   (en ajoutant `/api` à la fin, ex: `https://belerzone-backend.up.railway.app/api`)
2. Créez un compte sur https://netlify.com
3. Glissez-déposez le dossier `frontend/` dans Netlify (ou connectez votre dépôt GitHub,
   avec "Publish directory" = `frontend`)
4. Une fois en ligne, retournez dans Railway et mettez à jour `FRONTEND_URL` avec l'URL Netlify

## 4. Créer votre premier compte admin
1. Sur votre site, créez un compte normal via le bouton "Connexion" > "Inscription"
2. Dans Supabase, allez dans **Table Editor > users**, trouvez votre ligne
   et changez la colonne `is_admin` de `false` à `true`
3. Reconnectez-vous — vous pouvez maintenant accéder à `votre-site.netlify.app/admin/`

## 5. Stockage des fichiers audio
Ce projet stocke uniquement des **liens** (`file_url`) vers vos fichiers, pas les fichiers
eux-mêmes. Solutions recommandées :
- **Supabase Storage** (gratuit jusqu'à 1 Go) — uploadez vos MP3 et collez le lien public
- Cloudinary, Backblaze B2, ou tout hébergeur de fichiers avec lien direct

## API — Résumé des routes
| Méthode | Route | Auth | Description |
|---|---|---|---|
| POST | /api/users/register | non | Créer un compte |
| POST | /api/users/login | non | Se connecter (renvoie un token JWT) |
| GET | /api/users/me | oui | Profil connecté |
| GET | /api/users | admin | Liste des utilisateurs |
| DELETE | /api/users/:id | admin | Supprimer un utilisateur |
| GET | /api/beats | non | Liste des beats |
| POST | /api/beats | admin | Ajouter un beat |
| PUT | /api/beats/:id | admin | Modifier un beat |
| DELETE | /api/beats/:id | admin | Supprimer un beat |
| POST | /api/orders | oui | Passer une commande |
| GET | /api/orders/mine | oui | Mes commandes |
| GET | /api/orders | admin | Toutes les commandes |
| PUT | /api/orders/:id/status | admin | Changer le statut d'une commande |

## En local
```bash
cd backend
cp .env.example .env   # puis remplir les valeurs
npm install
npm run dev             # nécessite nodemon (npm install -g nodemon)
```
Puis ouvrez `frontend/index.html` directement dans un navigateur (ou via une extension
type "Live Server"), avec `API_URL` pointant vers `http://localhost:5000/api`.
